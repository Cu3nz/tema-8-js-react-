import React from 'react';

function Inicio() {
  return (
    <div>
      <h1>Pagina princial</h1>
      <p>Página principal</p>
    </div>
  );
}

export default Inicio;